# async-task-core

TypeScript SDK for the Allegiance AI **async job ledger**: fire a detached, deploy-durable worker on the VM, keep its ledger entry alive, and post the terminal result that the `async-completion-daemon` delivers back to the user on their originating channel (Google Chat / Gmail / Asana).

This is the TypeScript sibling of the Python [`async-bridge-core`](https://github.com/optimize-overseas/allegiance-ai/tree/main/async-bridge-core) (allegiance-ai repo), built for the TS/Node skills that run their heavy work on the VM: the courthouse-docs MCP, the closingdocument MCP, lacrm-mcp's bulk worker, and oseberg-file-review.
One protocol, three language SDKs (Python `async-bridge-core`, TS `async-task-core`, PHP `asynckit`) - a fire site never hand-rolls the ledger HTTP contract.

Node 20+, CommonJS, **zero runtime dependencies** (node builtins only).

## Why it exists

The `async-completion-daemon` (VM loopback `:9102`) is the single Firestore writer of the `async_jobs` ledger and the sole on-channel delivery path.
A skill that detaches long work must register that work in the ledger, or nothing delivers its result once the AI's turn ends - the "AI babysits a poll loop" pattern dies with the turn.
This SDK is how a TS/Node fire site speaks that contract:

1. `createJob` registers the job (and its `requestSummary`, the completion composer's self-contained context) - on failure it THROWS, and the caller degrades to its synchronous path instead of detaching an untracked job.
2. `spawnDetachedWorker` launches the worker in its own transient `systemd-run --user --scope` cgroup so a deploy's `KillMode=mixed` restart cannot SIGKILL it mid-run.
3. `startHeartbeat` / `postProgress` keep the ledger entry inside the daemon's stale window while the worker runs.
4. `terminalUpdate` posts the one update that must not be lost (status + result), with the shared 1/2/4/8 s retry ladder.

## The two-sided contract (and why the tests are byte-pinned)

The daemon's TS types live in the allegiance-ai repo and **cannot be imported across repos**, so the compiler cannot enforce the wire contract.
Instead, `tests/ledger-client.test.ts` and `tests/detached-spawn.test.ts` pin the ledger JSON and the `systemd-run` argv **byte-for-byte** - those tests ARE the contract.
If a pin must change, the daemon and the other SDKs change in the same initiative, never unilaterally.

Wire surface (all POST, loopback `http://127.0.0.1:9102`, override with `ASYNC_DAEMON_URL`):

| Endpoint | Body | Semantics |
|---|---|---|
| `/ledger/create` | `{skill, channel, requestorEmail, identifier[, requestSummary]}` | returns `{ok, jobId}`; throws `LedgerError` on any failure or missing jobId |
| `/ledger/update` | `{jobId[, progress][, status][, result][, finishedAt]}` | best-effort; empty patch = pure heartbeat |
| `/ledger/cancel` | `{jobId, reason}` | retire a registered-but-never-started job (spawn refused after a successful create) |

The three identity fields are flat and case-exact, read by the AI from its own message: `channel` (`gmail` \| `asana` \| `googlechat`), `requestorEmail`, and `identifier` (gmail message id / asana task gid / gchat space `spaces/<ID>`).
The daemon derives everything else (sessionKey, channelRef, frozen GChat account) - the fire site never builds a channel descriptor.

`requestSummary` (ledger v2) is a 1-3 sentence plain-language restatement of what the user asked for, authored by the AI at fire time.
It is optional on the wire (pre-v2 callers) but REQUIRED by the async checklist for every new fire site - it is what makes completion re-invocation self-contained after the originating session is archived.

## Public API

```ts
import {
  LedgerClient, LedgerError,
  spawnDetachedWorker,
  startHeartbeat, postProgress,
  nowMs,
} from '@optimizeoverseas/async-task-core';

// ---- fire side (inside the MCP tool / HTTP handler) ----
const ledger = new LedgerClient();
let jobId: string;
try {
  jobId = await ledger.createJob({
    skill: 'courthouse',
    channel, requestorEmail, identifier,        // read by the AI from its own message
    requestSummary,                              // authored by the AI at fire time
  });
} catch (exc) {                                  // LedgerError
  return runSynchronously();                     // degrade - never detach untracked work
}

const spawned = await spawnDetachedWorker({
  unitPrefix: 'chworker',                        // MUST match the registry row (see below)
  jobId,
  argv: ['node', '/opt/courthouse-docs-mcp/build/worker.js', '--job', jobId],
  logFile: '/tmp/chworker.log',                  // optional
});
if (!spawned.ok) {
  await ledger.cancelJob(jobId, `spawn refused: ${spawned.error}`);
  return runSynchronously();                     // single delivery, no contradictory reply
}
// ack the user with the jobId and END THE TURN - the daemon delivers the rest.

// ---- worker side (build/worker.js) ----
const hb = startHeartbeat(ledger, jobId);        // unref'd; never pins the process alive
await postProgress(ledger, jobId, '3/10 documents', 30_000);  // optional throttle
// ... the heavy work ...
hb.stop();
await ledger.terminalUpdate(jobId, {
  status: 'SUCCEEDED',                           // or 'FAILED' / 'REVIEW_REQUIRED'
  result: { links, counts, userText },           // userText = the verbatim fallback text
  finishedAt: nowMs(),
});
```

`terminalUpdate` returns a boolean after up to 4 attempts (1/2/4/8 s ladder, mirrored from `pdfsplit-async.py`); on `false` the daemon's stale-heartbeat detector is the last-resort backstop.
`updateJob` / `cancelJob` are best-effort and never throw.
All I/O goes through an injectable `postFn`, so consumer tests never open sockets.

## The spawn pattern: probe, then scope - REFUSE on failure

`spawnDetachedWorker` first probes `systemd-run --user --scope --quiet /bin/true` (10 s timeout) to prove the user bus is actually reachable, then spawns:

```
systemd-run --user --scope --quiet --collect --unit=<prefix>-<jobId> setsid <argv...>
```

`jobId` is validated against `^[A-Za-z0-9_-]+$` and `unitPrefix` against `^[a-z][a-z0-9-]*$` BEFORE any unit-name use.
When XDG_RUNTIME_DIR / DBUS_SESSION_BUS_ADDRESS are missing from the environment they are rehydrated from `process.getuid()` for both the probe and the spawn (long-lived MCP processes can outlive their login environment).

**A failed probe returns `{ok:false}` - there is deliberately NO bare-setsid fallback**, unlike the Python `detached_spawn.py` this ports.
A bare detached child sits in the host service's cgroup, where the next deploy SIGKILLs it mid-run; the Python original tolerated that as a WARNING-level degraded mode only because its agent's drain counts fallback workers.
Every consumer of this SDK has a documented synchronous path instead, so the correct reaction to `{ok:false}` is: `cancelJob` the ledger entry, run the work in-turn, reply once.
A refusal is loud and recoverable; a silently killable worker is neither.

## Consumer obligations (non-optional)

Every spawn site using this SDK MUST, in the same change:

1. **Registry row in allegiance-ai** - add a row to `scripts/detached-worker-registry.txt` with an inflight wrapper and the **`external:<repo>` spawn-site marker**, e.g.:

   ```
   courthouse | chworker-*.scope | courthouse-async-inflight.sh | auto-deploy | external:courthousedocumentdigitization-mcp
   ```

   The structural guard (`infrastructure/deploy/detached-worker-registry.test.cjs`) cannot grep a sister repo, so the marker declares the owning repo and shifts the pin there.

2. **Mirror test in the consuming repo** - pin the unit prefix so a rename cannot silently orphan the registry row.
   Copy-paste template:

   ```ts
   // tests/detached-worker-registry.mirror.test.ts
   //
   // MIRROR of the allegiance-ai detached-worker registry row for THIS repo:
   //   courthouse | chworker-*.scope | courthouse-async-inflight.sh | auto-deploy | external:courthousedocumentdigitization-mcp
   // (allegiance-ai scripts/detached-worker-registry.txt)
   //
   // The registry's structural guard cannot see spawn sites in this repo, so
   // this test is the sister half of that contract: if the unit prefix here
   // changes, the registry row, the inflight wrapper glob, and this pin must
   // all change in the same initiative - otherwise pre-deploy drains stop
   // seeing our in-flight workers and a deploy can kill them mid-run.
   import { WORKER_UNIT_PREFIX } from '../src/async-fire'; // wherever the spawn site keeps it
   test('worker unit prefix matches the allegiance-ai detached-worker-registry row', () => {
     expect(WORKER_UNIT_PREFIX).toBe('chworker');
   });
   ```

   Keep the prefix in ONE exported constant and pass it to `spawnDetachedWorker` - never inline the string twice.

3. **`DELIVERABLE_SKILLS` row** in the daemon (allegiance-ai `async-completion-daemon/src/ledger.ts`) for the skill name used in `createJob`, or `/ledger/create` rejects the fire.

## Install (sister-package convention)

Not published to a registry.
Consumed the way the other in-VM sister packages vendor local deps: install from a path or a packed tarball, so the consumer's lockfile pins the exact bits.

```bash
# from a checkout next to the consumer (dev):
npm install ../async-task-core

# or from a tarball (deploy; `prepare` builds dist/ on pack):
cd async-task-core && npm pack        # -> optimizeoverseas-async-task-core-0.1.0.tgz
cd ../courthousedocumentdigitization-mcp && npm install ../async-task-core/optimizeoverseas-async-task-core-0.1.0.tgz
```

The package ships `dist/` only (`files`), builds via `prepare` on install-from-path/pack, and declares `engines.node >= 20`.
Consumers keep their normal build (`tsc`) and test (`vitest`/`jest`) setups - this package imports as plain CommonJS, exactly like the registry deps in e.g. `courthousedocumentdigitization-mcp/package.json`.
On the VM the consuming MCPs live in `/opt/<name>` checkouts and deploy via `git pull` + `npm install` + `npm run build` (see allegiance-ai `integration-guide/12-external-repos.md`), so a bumped tarball/path install rides the same recipe.

## Fire-side checklist (async-everywhere master plan § 7, condensed)

- Fire through this SDK - never hand-rolled ledger HTTP.
- The fire carries `channel`, `requestorEmail`, `identifier` (case-exact) and `requestSummary`; it runs FOREGROUND (never backgrounded, never `sessions_yield`).
- On `{jobId}`: post a one-line ack and END THE TURN.
- On `LedgerError` or a spawn refusal: degrade to the documented sync fallback in the same call (after `cancelJob` when create had succeeded).
- The worker is deploy-durable (`spawnDetachedWorker` scope; a failed probe REFUSES) and drain-visible (inflight wrapper + registry row + `external:` marker + mirror test).
- The worker heartbeats and terminal-posts `userText` (the fallback text) + links.
- Docs in the same change: SKILL.md fire+ack+end-turn shape, HELP.md fragment, skill-catalog row, guide-05 drain note, `DELIVERABLE_SKILLS` row.
- E2E on the originating channel: fire, deliver, restart-survival, forced-compose-fallback.

## Test

```bash
npm install && npm run build && npm test
```

All tests run against injected fakes plus one real-loopback HTTP block and a PATH-stubbed `systemd-run` - nothing touches systemd or the real daemon.
