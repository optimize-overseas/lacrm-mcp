# async-task-core

TypeScript SDK for firing **detached, deploy-durable workers** that report to a loopback **async-job ledger daemon**.
Fire a long-running worker in its own transient systemd scope, keep its ledger entry alive with heartbeats, and post the one terminal update that must not be lost.

Node 20+, CommonJS, **zero runtime dependencies** (node builtins only).

## What it does

A process that detaches long work has two problems:

1. **Delivery** - once the firing turn or request ends, something must still track the job and deliver its result. That something is a host-side ledger daemon; this SDK is how a worker and its fire site speak to it.
2. **Durability** - a bare detached child stays in the hosting service's cgroup, where the next deploy's restart SIGKILLs it mid-run. `spawnDetachedWorker` puts the worker in its own transient `systemd-run --user --scope` cgroup instead, so a restart of the hosting service cannot reap it.

The pieces:

- `LedgerClient` - `createJob` / `updateJob` / `terminalUpdate` / `cancelJob` over the ledger HTTP contract.
- `spawnDetachedWorker` - the probe-then-scope spawn, with a REFUSE-on-failure design (below).
- `startHeartbeat` / `postProgress` - keep the ledger entry inside the daemon's stale window while the worker runs.

## The ledger HTTP contract

All endpoints are POST against a loopback daemon, default `http://127.0.0.1:9102`, overridable with the `ASYNC_DAEMON_URL` environment variable (or an explicit `baseUrl` option).

| Endpoint | Body | Semantics |
|---|---|---|
| `/ledger/create` | `{skill, channel, requestorEmail, identifier[, requestSummary]}` | returns `{ok, jobId}`; throws `LedgerError` on any failure or missing jobId |
| `/ledger/update` | `{jobId[, progress][, status][, result][, finishedAt]}` | best-effort; empty patch = pure heartbeat |
| `/ledger/cancel` | `{jobId, reason}` | retire a registered-but-never-started job (spawn refused after a successful create) |

Degradation rules:

- `createJob` THROWS (`LedgerError`) so the caller degrades to its synchronous in-process path instead of detaching an untracked job.
- `updateJob` / `cancelJob` are best-effort and never throw - a dropped heartbeat self-heals on the next one.
- `terminalUpdate` is the one update that must not be lost (status + result + finishedAt). It retries up to 4 attempts on a fixed 1/2/4/8 s ladder, then returns `false`; the daemon's stale-heartbeat detection is the last-resort backstop.

Terminal statuses are `SUCCEEDED`, `FAILED`, and `REVIEW_REQUIRED`; the result carries `links`, `counts`, a user-facing `userText`, and (failures only) an operator-facing `reason`.

## The spawn pattern: probe, then scope - REFUSE on failure

`spawnDetachedWorker` first probes `systemd-run --user --scope --quiet /bin/true` (10 s timeout) to prove the user bus is actually reachable - a down bus makes `systemd-run` exit non-zero before ever exec'ing the worker. Only then does it spawn:

```
systemd-run --user --scope --quiet --collect --unit=<prefix>-<jobId> setsid <argv...>
```

`--collect` reaps the unit when the worker exits; `setsid` detaches the session inside the scope. `jobId` is validated against `^[A-Za-z0-9_-]+$` and `unitPrefix` against `^[a-z][a-z0-9-]*$` before any unit-name use. When `XDG_RUNTIME_DIR` / `DBUS_SESSION_BUS_ADDRESS` are missing from the environment they are rehydrated from `process.getuid()` for both the probe and the spawn (a long-lived host process can outlive its login environment).

**A failed probe returns `{ok:false}` - there is deliberately NO bare-setsid fallback.**
A bare detached child sits in the host service's cgroup, where the next deploy SIGKILLs it mid-run.
Every consumer of this SDK should have a documented synchronous path instead, so the correct reaction to `{ok:false}` is: `cancelJob` the ledger entry, run the work in-process, reply once.
A refusal is loud and recoverable; a silently killable worker is neither.

## Public API

```ts
import {
  LedgerClient, LedgerError,
  spawnDetachedWorker,
  startHeartbeat, postProgress,
  nowMs,
} from '@optimizeoverseas/async-task-core';

// ---- fire side ----
const ledger = new LedgerClient();
let jobId: string;
try {
  jobId = await ledger.createJob({
    skill: 'myworker',
    channel, requestorEmail, identifier,   // identity fields your daemon expects
    requestSummary,                        // plain-language restatement of the request
  });
} catch (exc) {                            // LedgerError
  return runSynchronously();               // degrade - never detach untracked work
}

const spawned = await spawnDetachedWorker({
  unitPrefix: 'myworker',                  // ONE exported constant, registered with your drain tooling
  jobId,
  argv: ['node', '/srv/myapp/build/worker.js', '--job', jobId],
  logFile: '/tmp/myworker.log',            // optional
});
if (!spawned.ok) {
  await ledger.cancelJob(jobId, `spawn refused: ${spawned.error}`);
  return runSynchronously();               // single delivery, no contradictory reply
}
// ack the caller with the jobId and return - the daemon delivers the rest.

// ---- worker side (build/worker.js) ----
const hb = startHeartbeat(ledger, jobId);  // unref'd; never pins the process alive
await postProgress(ledger, jobId, '3/10 items', 30_000);  // optional throttle
// ... the heavy work ...
hb.stop();
await ledger.terminalUpdate(jobId, {
  status: 'SUCCEEDED',                     // or 'FAILED' / 'REVIEW_REQUIRED'
  result: { links, counts, userText },     // userText = the verbatim fallback text
  finishedAt: nowMs(),
});
```

All I/O goes through an injectable `postFn` (and the spawn through an injectable `spawnFn`/`probe`), so consumer tests never open sockets or touch systemd.

## Heartbeat

`startHeartbeat(client, jobId, intervalMs = 60_000)` posts an empty-patch heartbeat (`{jobId}`) on an interval (floored at 5 s - anything hotter is ledger spam).
The timer is unref'd so an in-flight heartbeat never pins a finished worker process alive; call `stop()` before the terminal update.
`postProgress` posts a progress line, with optional per-job throttling so a chatty per-item loop cannot flood the ledger; a progress post also refreshes the heartbeat daemon-side, so the two compose safely.

## Byte-pinned contract tests

Your host daemon's types cannot be imported across repos, so the compiler cannot enforce the wire contract.
This SDK's answer: **pin the wire JSON (and the `systemd-run` argv) byte-for-byte with tests.**
`tests/ledger-client.test.ts` and `tests/detached-spawn.test.ts` assert exact serialized bytes - those tests ARE the contract.
If a pin must change, the daemon and every SDK speaking the contract change in the same initiative, never unilaterally.
Adopt the same philosophy in your consumers: pin the strings your deployment tooling greps for.

## Consumer checklist

Every spawn site using this SDK should, in the same change:

1. **Register the worker's unit prefix with your host deployment's drain tooling.** Pre-deploy drains and restart gates enumerate in-flight workers by their `<prefix>-<jobId>` scope units; an unregistered prefix is invisible to them, and a deploy can kill the worker mid-run.
2. **Add a repo-local test pinning the prefix**, so a rename cannot silently orphan the registration:

   ```ts
   // tests/worker-prefix.test.ts
   //
   // The unit prefix is registered with the host deployment's drain tooling.
   // If it changes here, the registration must change in the same initiative -
   // otherwise pre-deploy drains stop seeing our in-flight workers.
   import { WORKER_UNIT_PREFIX } from '../src/async-fire'; // wherever the spawn site keeps it
   test('worker unit prefix matches the drain-tooling registration', () => {
     expect(WORKER_UNIT_PREFIX).toBe('myworker');
   });
   ```

   Keep the prefix in ONE exported constant and pass it to `spawnDetachedWorker` - never inline the string twice.

3. **Allow-list the skill name in your daemon** (whatever it uses to decide which skills it delivers), or `/ledger/create` rejects the fire.
4. On `LedgerError` or a spawn refusal, degrade to your documented synchronous fallback in the same call (after `cancelJob` when create had succeeded).

## Install (vendored tarball)

Not published to a registry. Consume it as a packed tarball vendored into the consumer repo:

```bash
cd async-task-core && npm pack        # -> optimizeoverseas-async-task-core-0.2.0.tgz
cd ../my-consumer && npm install ../async-task-core/optimizeoverseas-async-task-core-0.2.0.tgz
```

Why a tarball instead of a path dependency: a `file:../async-task-core` path dep dangles on any deployment checkout that does not have the sibling directory, while a vendored tarball travels with the consumer and lets its lockfile pin the exact bits.
The package ships `dist/` only (`files`), builds via `prepare` on pack, and declares `engines.node >= 20`.
It imports as plain CommonJS, so consumers keep their normal build and test setups.

## Test

```bash
npm install && npm run build && npm test
```

All tests run against injected fakes plus one real-loopback HTTP block and a PATH-stubbed `systemd-run` - nothing touches systemd or a real daemon.
